
/*var  datestring =new Date();
console.log(dateInString);
console.log("=========================");
var year = todayDate.getFullYear();
console.log(year);
console.log("================");
var months =['jan', 'feb','march','april','may','june','july','august','september','november'];
log("month console= "+months[todayDate.getMoth()]);
log("Day= "+months[todayDate.getDate()]);*/
console.log(Math.PI);
console.log(Math.floor(4.5));
console.log(Math.ceil(4.5));
console.log(Math.round(4.5));
console.log(Math.random(5));
console.log(Math.random(6));
console.log(Math.ceil(Math.random()*100));
var num= 10;
var num1= '10';
if(num===num1)/* to check equality*/
{
    console.log('equal');
}
else{
    console.log('not equal');
}
console.log("==================================");
var typeofNumber=typeof Numbervalue;
var typeofNumber1=typeof nummberValue1;
console.log(typeofNumber);

console.log(typeofNumber1);
var num1;
console.log(typeof num1);
var num2=null;

console.log(typeof booleanValue);
var  fruit=['oange','aple','banana'];
console.log(typeof fruit);
console.log("==============================");
var age= 21;
 var checkAge= (age>21)?'greater':(age===21)?'equal':'lesser';
 console.log(checkAge);
 var  number=10;
number+=10;
console.log(number);
 var Employe=[{ name:'priya',
                  age:33},
         { name:'aliya',
              age:20},
         {name:'bhagath',
           age:33}
        ];
    for( var i=0 ;i<Employe.length;i++)
    {
        console.log(Employe[i]);
    }

    var hobbies=['singing','jumping','scatting','laughing'];
    for(var value of hobbies){
        console.log(value);
    }
for( var index in hobbies){
    console.log( hobbies[index]);
}
 var person={name:'sazzu',
                age:20};
     for(var index in person)  
     {
         console.log(person[index]);
     }
     