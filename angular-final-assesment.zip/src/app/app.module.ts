import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms'
import{HttpClientModule} from '@angular/common/http';
import{ RouterModule} from '@angular/router';
import { AppComponent } from './app.component';
import { HeadComponent } from './head/head.component';
import { UsersComponent } from './users/users.component';
import { TaskManagrComponent } from './task-managr/task-managr.component';
import { HomeComponent } from './home/home.component';


@NgModule({
  declarations: [
    AppComponent,
    HeadComponent,
    UsersComponent,
    TaskManagrComponent,
    HomeComponent,
  
    
  ],
  
  imports: [
    RouterModule.forRoot([
      {path:'users', component: UsersComponent},
      {path:'home', component: HomeComponent},
      {path:'task-managr', component: TaskManagrComponent},
  
  ]),
  BrowserModule,
  HttpClientModule,
  FormsModule
],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
