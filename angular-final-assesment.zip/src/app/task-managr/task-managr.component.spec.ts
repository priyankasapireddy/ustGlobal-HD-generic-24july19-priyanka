import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskManagrComponent } from './task-managr.component';

describe('TaskManagrComponent', () => {
  let component: TaskManagrComponent;
  let fixture: ComponentFixture<TaskManagrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskManagrComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskManagrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
