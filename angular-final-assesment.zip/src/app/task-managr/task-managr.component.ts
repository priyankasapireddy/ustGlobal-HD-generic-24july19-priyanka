import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
  

@Component({
  selector: 'app-task-managr',
  templateUrl: './task-managr.component.html',
  styleUrls: ['./task-managr.component.css']
})
export class TaskManagrComponent implements OnInit {
 task:any[]=[];
  constructor() {
    
   }
   addTask(loginForm:NgForm){
    console.log(loginForm.value);
    this.task.push(loginForm.value);
    loginForm.reset();
    console.log(this.task);
    
   }
   removeUser(tasks){

    let index= this.task.indexOf(tasks);
    this.task.splice(index,1);
  
  }

  ngOnInit() {
  }

}
