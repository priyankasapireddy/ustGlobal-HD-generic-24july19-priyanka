import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-validator',
  templateUrl: './custom-validator.component.html',
  styleUrls: ['./custom-validator.component.css']
})
export class CustomValidatorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
