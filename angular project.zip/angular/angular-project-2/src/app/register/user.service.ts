import{Injectable}from '@angular/core';

@Injectable({
 providedIn:"root"
})
export class userService{
  users=[
      {
          name:'priyanka',
          company:'ust global'
      },
      {
          name:'supriya',
          comp:'ustglobal'
      },
      {
          name:'bhavani',
          company:'ust global'
      }
  ]
}
