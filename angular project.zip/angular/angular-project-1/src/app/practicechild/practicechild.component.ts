import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-practicechild',
  templateUrl: './practicechild.component.html',
  styleUrls: ['./practicechild.component.css']
})
export class PracticechildComponent implements OnInit {

@Output() childData = new EventEmitter();
@Input()  dataFromParent='';
  constructor() { }
  
  ngOnInit() {
    this.childData.emit('this is data from child');

  }

}
