import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipies',
  templateUrl: './recipies.component.html',
  styleUrls: ['./recipies.component.css']
})
export class RecipiesComponent implements OnInit {
  recipiData:any='';
recipi=[
  {
 variety:'cherry',
img:'https://cdn.pixabay.com/photo/2017/01/31/09/30/raspberry-2023404__340.jpg',
description:'Food is any substance consumed to provide nutritional support for an organism. It is usually of plant or animal origin, and contains essential nutrients, such as carbohydrates, fats, proteins, '
},
{
  variety:'blueberry',
 img:'https://cdn.pixabay.com/photo/2016/04/13/07/18/blueberry-1326154__340.jpg',
 description:'Food is any substance consumed to provide nutritional support for an organism. It is usually of plant or animal origin, and contains essential nutrients, such as carbohydrates, fats, proteins. '
 },
 {
  variety:'icecreem',
 img:'https://cdn.pixabay.com/photo/2016/03/23/15/00/ice-cream-cone-1274894__340.jpg',
 description:'Food is any substance consumed to provide nutritional support for an organism. It is usually of plant or animal origin, and contains essential nutrients, such as carbohydrates, fats, proteins. '
 },
 {
  variety:'salad',
 img:'https://cdn.pixabay.com/photo/2017/02/15/10/39/salad-2068220__340.jpg',
 description:'Food is any substance consumed to provide nutritional support for an organism. It is usually of plant or animal origin, and contains essential nutrients, such as carbohydrates, fats, proteins. '
 }
  
]
  constructor() { }
  sendRecipi(recipi){
    this.recipiData= recipi;
    console.log(recipi);
  }
  
  ngOnInit() {
  }

}
