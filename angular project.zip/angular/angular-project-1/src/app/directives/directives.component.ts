import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {
  condition='false';
users=[
  {
    id:12234,
    name:'priyanka',
    city:'pune'
  },
  {
    id:23345,
    name:'rana',
    city:'thirupathi'
  },
  {
    id:233466,
    name:'swarna',
    city:'kerala'
  },
  {
    id:75566,
    name:'supriya',
    city:'bombay'
  },
  {
    id:90065,
    name:'sazzu',
    city:'blackpond'
  }
]
  constructor() { }
  removeUser(user){
    let index= this.users.indexOf(user);
    this.users.splice(index,1);
    this.condition='true'
  }
  ngOnInit() {
    
  }

}
