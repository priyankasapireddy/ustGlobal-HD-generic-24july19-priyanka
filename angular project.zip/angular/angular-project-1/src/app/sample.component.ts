import {Component} from "@angular/core";
@Component({
    selector:'app-sample',
    template:`
    <h1> sample component is working </h1>
    `,
    styles :['h1{background:red, color:white}']
})
export class sampleComponent{

}