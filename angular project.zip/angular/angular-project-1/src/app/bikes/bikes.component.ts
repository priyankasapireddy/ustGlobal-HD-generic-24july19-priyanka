import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bikes',
  templateUrl: './bikes.component.html',
  styleUrls: ['./bikes.component.css']
})
export class BikesComponent implements OnInit {
  bikeData:any='';
 bike=[
   {
     brand:'KTM',
     img:'https://cdn.pixabay.com/photo/2015/05/20/07/57/grassland-774929__340.jpg',
    description:'Search New Motorcycles In India. Get Complete Research With Prices. Dealers & Service Center. Most Accurate Price. Full Details of Bike. Expert Reviews. Brands: Aprilia, Benelli, BMW, Ducati, Hyosung, Kawasaki, MVAgusta, Moto Guzzi, Tork, Triumph.'

   },
   {
    brand:'RX100',
    img:'https://cdn.pixabay.com/photo/2016/04/07/06/53/bmw-1313343_960_720.jpg',
   description:'Buy 50 Used Yamaha Rx 100 Bikes available for sale online in India. All Yamaha Rx 100 Bikes are available at best price starting from Rs. 15,000 to Rs. 1,25,000. Second hand Yamaha Rx 100 Bikes available in two different pricing formats – Fixed Price and Best Offer. Select any model by trim, check all the specifications, owner details, transmission type and get certified pre-owned Yamaha Rx 100 Bikes in India.'
   },
   {
     brand:'apche',
     img:'https://cdn.pixabay.com/photo/2015/09/08/21/02/superbike-930715__340.jpg',
     description:'Buy 50 Used Yamaha Rx 100 Bikes available for sale online in India. All Yamaha Rx 100 Bikes are available at best price starting from Rs. 15,000 to Rs. 1,25,000. Second hand Yamaha Rx 100 Bikes available in two different pricing formats – Fixed Price and Best Offer. Select any model by trim, check all the specifications, owner details, transmission type and get certified pre-owned Yamaha Rx 100 Bikes in India.',

   },
   {
    brand:'yamaha',
    img:'https://cdn.pixabay.com/photo/2014/03/25/16/26/motorbike-297090__340.png',
    description:'24x7 assured roadside assistance, extended warranties, customized insurance plan. Take your business to new heights with our Sampoorna Seva package. Enquire Now. Enquire Online. Highlights: We Are A Global Automobile Manufacturer, Founded In 1868.'

   },
   {
     brand:'FZ-5',
     img:'https://cdn.pixabay.com/photo/2016/08/04/18/14/bike-1569679_960_720.jpg',
     description:'The Yamaha FZ series is the most popular motorcycle for the Japanese two-wheeler giant in India. It was updated with fuel injection and revised styling a few years back and was christened Yamaha ...'
   }
 ]
  constructor() { }
sendBike(bike){
  this.bikeData= bike;
  console.log(bike);
}
  ngOnInit() {
  }

}
