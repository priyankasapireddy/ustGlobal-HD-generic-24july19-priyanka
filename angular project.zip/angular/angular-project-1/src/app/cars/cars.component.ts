import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
export class CarsComponent implements OnInit {
  carData:any='';
  car=[
    {
      brand:'audi',
      img:'https://cdn.pixabay.com/photo/2016/12/03/11/47/car-1879630__340.jpg',
     description:'A car (or automobile) is a wheeled motor vehicle used for transportation. Most definitions of car say they run primarily on roads, seat one to eight people, have four tires, and mainly transport people rather than goods.Cars came into global use during the 20th century, and developed economies depend on them.',
    },
    {
      brand:'benz',
      img:'https://cdn.pixabay.com/photo/2018/05/20/23/36/mercedes-3417100__340.jpg',
     description:'A car (or automobile) is a wheeled motor vehicle used for transportation. Most definitions of car say they run primarily on roads, seat one to eight people, have four tires, and mainly transport people rather than goods.Cars came into global use during the 20th century, and developed economies depend on them.',
    },
    {
      brand:'toyoto',
      img:'https://cdn.pixabay.com/photo/2012/11/02/13/02/ford-63930__340.jpg',
     description:'A car (or automobile) is a wheeled motor vehicle used for transportation. Most definitions of car say they run primarily on roads, seat one to eight people, have four tires, and mainly transport people rather than goods.Cars came into global use during the 20th century, and developed economies depend on them.',
    },
    {
      brand:'swift',
      img:'https://cdn.pixabay.com/photo/2015/01/08/15/30/lamborghini-593105__340.jpg',
     description:'A car (or automobile) is a wheeled motor vehicle used for transportation. Most definitions of car say they run primarily on roads, seat one to eight people, have four tires, and mainly transport people rather than goods.Cars came into global use during the 20th century, and developed economies depend on them.',
    },
    {
      brand:'shadow',
      img:'https://cdn.pixabay.com/photo/2014/09/07/22/34/car-race-438467__340.jpg',
     description:'A car (or automobile) is a wheeled motor vehicle used for transportation. Most definitions of car say they run primarily on roads, seat one to eight people, have four tires, and mainly transport people rather than goods.Cars came into global use during the 20th century, and developed economies depend on them.'
    }
  ]
  constructor() { }
 sendCar(car){
   this.carData=car;
   console.log(car);

 }
  ngOnInit() {
  }

}
