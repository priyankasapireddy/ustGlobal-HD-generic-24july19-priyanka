import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-practiceif',
  templateUrl: './practiceif.component.html',
  styleUrls: ['./practiceif.component.css']
})
export class PracticeifComponent implements OnInit {
pdata='parent data is here';
  constructor() { }
  
  ngOnInit() {
  }

}
