import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PracticeifComponent } from './practiceif.component';

describe('PracticeifComponent', () => {
  let component: PracticeifComponent;
  let fixture: ComponentFixture<PracticeifComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PracticeifComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PracticeifComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
