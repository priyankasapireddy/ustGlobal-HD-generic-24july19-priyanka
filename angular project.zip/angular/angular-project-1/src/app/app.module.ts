import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { sampleComponent } from './sample.component';
import { HeaderComponent } from './header/header.component';
import { TwoWayComponent } from './two-way/two-way.component';
import {from} from 'rxjs';
import { DirectivesComponent } from './directives/directives.component';
import { IfElseComponent } from './if-else/if-else.component';
import { AttributeDirectivesComponent } from './attribute-directives/attribute-directives.component';
import { MyDirectiveDirective } from './my-directive.directive';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { BikesComponent } from './bikes/bikes.component';
import { BikeDetailsComponent } from './bike-details/bike-details.component';
import { CarsComponent } from './cars/cars.component';
import { CarDetailsComponent } from './car-details/car-details.component';
import { RecipiesComponent } from './recipies/recipies.component';
import { RecipieDetailsComponent } from './recipie-details/recipie-details.component';
import { PracticeifComponent } from './practiceif/practiceif.component';
import { PracticechildComponent } from './practicechild/practicechild.component';
@NgModule({
  declarations: [
    AppComponent,
    sampleComponent,
    HeaderComponent,
    TwoWayComponent,
    DirectivesComponent,
    IfElseComponent,
    AttributeDirectivesComponent,
    MyDirectiveDirective,
    ParentComponent,
    ChildComponent,
    BikesComponent,
    BikeDetailsComponent,
    CarsComponent,
    CarDetailsComponent,
    RecipiesComponent,
    RecipieDetailsComponent,
    PracticeifComponent,
    PracticechildComponent
  ],
  imports: [
    BrowserModule,
   FormsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
